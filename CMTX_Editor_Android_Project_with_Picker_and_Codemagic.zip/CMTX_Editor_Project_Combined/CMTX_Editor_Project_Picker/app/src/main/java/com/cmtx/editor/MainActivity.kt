package com.cmtx.editor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayOutputStream
import java.io.InputStream

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var pendingSaveDataUrl: String? = null
    private var pendingSaveFileName: String? = null
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null

    companion object {
        const val REQ_OPEN_DOCUMENT = 1001
        const val REQ_CREATE_DOCUMENT = 1002
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webView)

        val ws = webView.settings
        ws.javaScriptEnabled = true
        ws.domStorageEnabled = true
        ws.allowFileAccess = true
        ws.allowContentAccess = true
        ws.setSupportMultipleWindows(false)

        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectBlobHijack()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            // This will be called for <input type="file"> in the page.
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                // Store callback and launch Android picker
                pendingFileCallback = filePathCallback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(intent, REQ_OPEN_DOCUMENT)
                return true
            }
        }

        webView.loadUrl("file:///android_asset/Cmtx_Esword_Editor.html")
    }

    // Inject JS to intercept URL.createObjectURL for Blobs so we can capture exports
    private fun injectBlobHijack() {
        val js = """
            (function(){
              if(window.__cmtx_blob_hijacked) return;
              window.__cmtx_blob_hijacked = true;
              const orig = URL.createObjectURL;
              URL.createObjectURL = function(obj){
                try{
                  if(obj && obj instanceof Blob){
                    var fr = new FileReader();
                    fr.onload = function(e){
                      try{
                        var data = e.target.result;
                        // find last anchor with download attribute if any
                        var a = document.querySelector('a[download]');
                        var fname = a && a.download ? a.download : ('CMTX_export.cmtx');
                        if(window.AndroidBridge && window.AndroidBridge.saveFile){
                          window.AndroidBridge.saveFile(data, fname);
                        }
                      }catch(err){}
                    };
                    fr.readAsDataURL(obj);
                  }
                }catch(e){}
                return orig.apply(this, arguments);
              };
            })();
        """.strip()
        webView.evaluateJavascript(js, null)
    }

    // Handle results from open/create document intents
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OPEN_DOCUMENT) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                val uri: Uri? = data.data
                if (uri != null) {
                    // Read bytes and convert to base64 then inject into page as a File
                    try {
                        val input: InputStream? = contentResolver.openInputStream(uri)
                        val bytes = readAllBytes(input)
                        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                        val filename = queryFileName(uri) ?: "import.cmtx"
                        // Construct JS to create a File and set it on the hidden file input with id 'fileInput'
                        val js = """
                            (function(){
                                try{
                                    var b64 = '$b64';
                                    var fname = '${escapeJsString(filename)}';
                                    var data = atob(b64);
                                    var arr = new Uint8Array(data.length);
                                    for(var i=0;i<data.length;i++){ arr[i]=data.charCodeAt(i); }
                                    var blob = new Blob([arr], {type: 'application/octet-stream'});
                                    var file = new File([blob], fname, {type:'application/octet-stream'});
                                    var input = document.getElementById('fileInput');
                                    if(!input){
                                        // fallback: try to find first file input
                                        input = document.querySelector('input[type=file]');
                                    }
                                    if(input){
                                        var dt = new DataTransfer();
                                        dt.items.add(file);
                                        input.files = dt.files;
                                        var ev = new Event('change');
                                        input.dispatchEvent(ev);
                                    }
                                }catch(e){}
                            })();
                        """.trimIndent()
                        webView.evaluateJavascript(js, null)
                        // Also notify any stored file callback with the uri so WebView internals may accept it
                        pendingFileCallback?.onReceiveValue(arrayOf(uri))
                        pendingFileCallback = null
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                } else {
                    pendingFileCallback?.onReceiveValue(null)
                    pendingFileCallback = null
                }
            } else {
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = null
            }
        } else if (requestCode == REQ_CREATE_DOCUMENT) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                val uri = data.data
                if (uri != null && pendingSaveDataUrl != null) {
                    try {
                        // pendingSaveDataUrl is a data:...;base64,....
                        val dataUrl = pendingSaveDataUrl!!
                        val comma = dataUrl.indexOf(',')
                        val meta = dataUrl.substring(5, comma)
                        val isBase64 = meta.contains(";base64")
                        val payload = dataUrl.substring(comma + 1)
                        val bytes = if (isBase64) Base64.decode(payload, Base64.DEFAULT) else payload.toByteArray(Charsets.UTF_8)
                        val out = contentResolver.openOutputStream(uri)
                        out?.write(bytes)
                        out?.close()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
            pendingSaveDataUrl = null
            pendingSaveFileName = null
        }
    }

    private fun readAllBytes(input: InputStream?): ByteArray {
        val buffer = ByteArrayOutputStream()
        if (input == null) return ByteArray(0)
        val data = ByteArray(4096)
        var n: Int
        while (true) {
            n = input.read(data)
            if (n <= 0) break
            buffer.write(data, 0, n)
        }
        return buffer.toByteArray()
    }

    private fun queryFileName(uri: Uri): String? {
        // best-effort: try to get last path segment
        return uri.lastPathSegment?.split('/')?.last()
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun saveFile(dataUrl: String, filename: String) {
            // Called from injected JS when page attempts to createObjectURL for Blob
            pendingSaveDataUrl = dataUrl
            pendingSaveFileName = filename
            // Launch create document intent
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_TITLE, filename)
            }
            startActivityForResult(intent, REQ_CREATE_DOCUMENT)
        }
    }
}
