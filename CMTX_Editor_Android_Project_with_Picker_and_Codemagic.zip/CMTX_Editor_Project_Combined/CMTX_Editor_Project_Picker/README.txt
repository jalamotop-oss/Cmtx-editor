CMTX Editor - Android Studio project (Kotlin, WebView wrapper) WITH file picker support

How it works:
- Opening files: When the page triggers a file input, the WebChromeClient opens the Android picker. The selected file is read and injected into the page's hidden file input element so the app's existing file-load code runs as-is.
- Exporting files: The app intercepts Blob -> URL.createObjectURL calls and reads the blob, then calls the AndroidBridge.saveFile(dataUrl, filename) to open a Save dialog. The chosen location is written with the exported bytes.

How to build:
1. Unzip this archive.
2. Open the folder in Android Studio (Open an existing Android Studio project).
3. Let Android Studio download/upgrade Gradle if prompted.
4. Build -> Build APK(s) or Run on an emulator/device.

Notes:
- This project cannot be compiled in this sandbox. Use Android Studio or a build service to produce the APK.
- Minimum SDK: 21 (Android 5.0). Target SDK: 33.
